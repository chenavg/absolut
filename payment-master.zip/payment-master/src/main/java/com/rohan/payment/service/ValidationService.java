package com.rohan.payment.service;

import org.springframework.stereotype.Service;

@Service
public class ValidationService {
}
