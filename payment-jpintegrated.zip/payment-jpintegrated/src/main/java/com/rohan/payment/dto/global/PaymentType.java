package com.rohan.payment.dto.global;

public class PaymentType {
}